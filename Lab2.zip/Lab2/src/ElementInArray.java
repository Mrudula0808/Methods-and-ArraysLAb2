import java.util.Scanner;

public class ElementInArray {
    public static void main(String[] args) {
        System.out.println("Please enter length of the array");
        Scanner scnr = new Scanner(System.in);
        int length = scnr.nextInt();
        int[] input = new int[length];
        System.out.println("Please enter numbers ");
        for (int i = 0; i < length; i++) {
            input[i] = scnr.nextInt();
        }

        System.out.println("Enter Value to search for ");
        int contains = scnr.nextInt();
        check(input,contains);
    }

    private static void check(int[] arr, int toCheckValue)
    {
        boolean test = false;
        for (int element : arr) {
            if (element == toCheckValue) {
                test = true;
                break;
            }
        }

        System.out.println("Is " + toCheckValue
                + " present in the array: " + test);
    }
}
